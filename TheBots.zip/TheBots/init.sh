#!/bin/sh
dir=`pwd`

/usr/lib/node_modules/nohup/bin/nohup $dir/run.py
