#!/bin/sh
ps aux | grep Thebot
